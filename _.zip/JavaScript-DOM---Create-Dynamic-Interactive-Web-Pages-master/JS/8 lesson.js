const h1 = document.querySelector('h1');
h1.style.padding = "25px";
h1.style.border = "5px dotted purple";
h1.style.fontSize = "40px";
h1.style.display = "none";
h1.style.display = "block";
h1.style.color = "yellow";
h1.style.backgroundColor = "red";