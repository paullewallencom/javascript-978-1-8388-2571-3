document.querySelector("h1").innerHTML = "wow that was easy";
console.dir(document);